class User: 
    def __init__(self, name, email_address):
        self.name = name
        self.email = email_address

class BankAccount:		
    def __init__(self, name, email_address, bank, int_rate, balance):
        self.bank = bank
        self.int_rate = int_rate
        self.name = name
        self.email = email_address
        self.account_balance = 0

    def make_deposit(self, amount):	
        self.account_balance += amount	
    def make_withdrawal(self, amount):
        self.account_balance -= amount
    def yield_interest(self):
        self.account_balance *= (self.int_rate + 1)
    def display_account_info(self):
        print("\n Net Available Balance=", self.account_balance)


brian = BankAccount("Brian", "brian@python.com", "First National Dojo", .01, 0)
monty = BankAccount("Monty", "monty@python.com", "First National Dojo", .01, 0)


monty.make_deposit(500)
monty.make_withdrawal(100)
monty.yield_interest()


brian.make_deposit(150)
brian.make_withdrawal(50)
brian.yield_interest()

print(brian.name, brian.email, brian.bank, brian.account_balance, brian.int_rate),brian.display_account_info() 

print(monty.name, monty.email, monty.bank, monty.account_balance, monty.int_rate),monty.display_account_info() 







